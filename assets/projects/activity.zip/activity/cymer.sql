-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2022 at 11:05 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cymer_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cymer`
--

CREATE TABLE `cymer` (
  `exp_id` int(11) NOT NULL,
  `exp_name` varchar(250) NOT NULL,
  `exp_address` varchar(500) DEFAULT NULL,
  `exp_dob` date NOT NULL,
  `exp_username` varchar(100) NOT NULL,
  `exp_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cymer`
--

INSERT INTO `cymer` (`exp_id`, `exp_name`, `exp_address`, `exp_dob`, `exp_username`, `exp_password`) VALUES
(1, 'CYMER JACOB DENAMPO', 'Sindulan Tina-an, City of Naga Cebu', '2001-04-11', 'denampocymer', '12345'),
(2, 'DAN CARLO CAÑALITA', ' ', '0000-00-00', 'canalitadancarlo', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cymer`
--
ALTER TABLE `cymer`
  ADD PRIMARY KEY (`exp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cymer`
--
ALTER TABLE `cymer`
  MODIFY `exp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
