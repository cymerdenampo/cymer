<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname= "cymer_db";

$conn = mysqli_connect($servername, $username, $password, $dbname);
?>



<!DOCTYPE html>
<html>
    <head>
        <title>Activity PHP MySQL</title>
        <style>
            table {
            border-collapse: collapse;
             width: 100%;
            }

            th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            }

            tr:hover {background-color: #04AA6D;}
            

            * {box-sizing: border-box}
            body{
                font-family:Verdana, Geneva, Tahoma, sans-serif;
            }

            /* Add padding to containers */
            .container {
            padding: 16px; width: 50%; margin: 0 auto; background-color:#ccc;
            }

            /* Full-width input fields */
            input[type=text], input[type=password],  input[type=date] {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background: #f1f1f1;
            }

            input[type=text]:focus, input[type=password]:focus, input[type=date]:focus {
            background-color: #ddd;
            outline: none;
            }

            /* Overwrite default styles of hr */
            hr {
            border: 1px solid #f1f1f1;
            margin-bottom: 25px;
            }

            /* Set a style for the submit/register button */
            .registerbtn {
            background-color: #04AA6D;
            color: white;
            padding: 16px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
            }

            .registerbtn:hover {
            opacity:1;
            }

            /* Add a blue text color to links */
            a {
            color: dodgerblue;
            }

            /* Set a grey background color and center the text of the "sign in" section */
            .signin {
            background-color: #f1f1f1;
            text-align: center;
            }
            
			table, th, td {
			border:0px solid black;
			}
        </style>
    </head>
    <body>
        <form action="" method="GET">
            <div class="container">
              <h1>Register</h1>
              <p>Please fill in this form to create an account.</p>
              <hr>
          
              <label for="email"><b>Fullname</b></label>
              <input type="text" placeholder="Enter Name" name="fullname" id="fullname" required>

              <label for="email"><b>Date of Birth</b></label>
              <input type="date"  name="dob" id="dob" required>

              <label for="email"><b>Address</b></label>
              <input type="text" placeholder="Enter Address" name="address" id="address" required>

          	  <label for="email"><b>Username</b></label>
              <input type="text" placeholder="Enter Username" name="username" id="username" required>

              <label for="psw"><b>Password</b></label>
              <input type="password" placeholder="Enter Password" name="psw" id="psw" required>
              
              <label for="psw-repeat"><b>Repeat Password</b></label>
              <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required><hr>
          
             
              <button type="submit" class="registerbtn" name="submit">Register</button>
            </div>
          
            
          </form>
          <table style = "width:100%">
              <tr>
                  <th>User ID</th>
                  <th>Fullname</th>
                  <th>Date of Birth</th>
                  <th>Address</th>
                  <th>Username</th>
                  <th>Password</th>
              </tr>

              <?php
                  $conn = mysqli_connect("localhost", "root", "", "cymer_db");
                  $sql = "SELECT * FROM cymer";
                  $result = $conn-> query($sql);

                  if ($result->num_rows > 0) {
                          while($row = $result-> fetch_assoc()){
                              echo " <tr>
                                  <td>" . $row["exp_id"] . "</td>
                                  <td>" . $row["exp_name"] . "</td>
                                  <td>" . $row["exp_dob"] . "</td>
                                  <td>" . $row["exp_address"] . "</td>
                                  <td>" . $row["exp_username"] . "</td>
                                  <td>" . $row["exp_password"] . "</td>
                              </tr> ";
                          }
                    }

              ?>
          </table>
    </body>

</html>

<?php 
 if(isset($_GET['submit'])){
 	$sql = "INSERT INTO cymer (exp_name, exp_dob, exp_address,  exp_username, exp_password) VALUES ('$_GET[fullname]','$_GET[dob]','$_GET[address]','$_GET[username]','$_GET[psw]')";
 	mysqli_query($conn, $sql);
}

?>