import com.mysql.jdbc.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;

public class dataconn {
    
    Connection conn = null;
    
    public static Connection ConnectDb(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/employee", "root", "");
            //JOptionPane.showConfirmDialog(null, "Connection Establish");
            return conn;
        
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null, e);
            
            return null;
        }
    }
    
}
