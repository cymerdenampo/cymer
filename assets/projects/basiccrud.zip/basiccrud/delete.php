<?php
if ( isset ($_GET["id"]) ) {
    $id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "trive_db";

    // Create a connection
    $connection = new mysqli($servername, $username, $password, $database);

    $sql = "DELETE FROM tribe WHERE id=$id";
    $connection->query($sql);
}

    header("location: /basiccrud/index.php");
    exit;
?>