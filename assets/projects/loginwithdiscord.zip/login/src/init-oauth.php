<?php

$discord_url = "https://discord.com/api/oauth2/authorize?client_id=1077897949331333211&redirect_uri=http%3A%2F%2Flocalhost%2Flogin%2Fsrc%2Fprocess-oauth.php&response_type=code&scope=identify%20guilds";
header("Location: $discord_url");
exit();

?>