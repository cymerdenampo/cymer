<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRIBE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="form-container" style="background-image: url('logoNew.jpg');">

    <form action="" method="post" style="padding: 100px; border-radius: 50px; box-shadow: 0 50px 50px rgba(0, 0, 0, .5); background: #f1d5a0; text-align: center; width: 800px;">
            <h1 style="text-align: center; font-size: 40pt; text-transform: capitalize; margin-top: 10px; color: #333; background-color: #fff0d2; padding: 12px 20px; border-radius: 50px; width: 100%;">
            Thankyou for Appying</h1>
    </form>

</div>
    
</body>
</html>