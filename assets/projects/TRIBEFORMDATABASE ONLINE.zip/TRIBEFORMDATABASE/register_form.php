<?php

@include 'config.php';

if(isset($_POST['submit'])){

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $discordname = ($_POST['discordname']);
    $discordmember = mysqli_real_escape_string($conn, $_POST['discordmember']);
    $discordid = ($_POST['discordid']);
    $user_type = $_POST['user_type'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $birth = ($_POST['birth']);
    $gender = ($_POST['gender']);
    $country = ($_POST['country']);
    $status = ($_POST['status']);
    $ronninwallet = mysqli_real_escape_string($conn, $_POST['ronninwallet']);
    $image = $_POST['image'];
    $game = $_POST['game'];
    $scholarship = $_POST['scholarship'];
    $work = $_POST['work'];
    $skills = $_POST['skills'];
    $employee = $_POST['employee'];
    $salary = $_POST['salary'];
    $socmed = $_POST['socmed'];
    $tc = $_POST['tc'];
    $internet = $_POST['internet'];
    $payout = $_POST['payout'];
    $admins = $_POST['admins'];
    $playing = $_POST['playing'];
    $axie_terms = $_POST['axie_terms'];
    $played_axie = $_POST['played_axie'];
    $guild_scholarship = $_POST['guild_scholarship'];
    $lastscholarship = $_POST['lastscholarship'];
    $rank = $_POST['rank'];
    $scholarships_interested = $_POST['scholarships_interested'];
    $stepn_agreement = $_POST['stepn_agreement'];
    $question1 = $_POST['question1'];
    $question2 = $_POST['question2'];
    $question3 = $_POST['question3'];
    $question4 = $_POST['question4'];
    $question5 = $_POST['question5'];
    $question6 = $_POST['question6'];
    $question7 = $_POST['question7'];
    $question8 = $_POST['question8'];
    $question9 = $_POST['question9'];
    $question10 = $_POST['question10'];
    $question11 = $_POST['question11'];
    $question12 = $_POST['question12'];
    $question13 = $_POST['question13'];
    $question14 = $_POST['question14'];
    $question15 = $_POST['question15'];
    $question16 = $_POST['question16'];
    $question17 = $_POST['question17'];
    $question18 = $_POST['question18'];
    $question19 = $_POST['question19'];
    $question20 = $_POST['question20'];
    $played_stepn = $_POST['played_stepn'];
    $guild_part = $_POST['guild_part'];
    $whydid_youleave = $_POST['whydid_youleave'];
    $account_prefer = $_POST['account_prefer'];
    $medical_conditions = $_POST['medical_conditions'];
    



    $select = " SELECT * FROM form WHERE email = '$email' ";

    $result = mysqli_query($conn, $select);

    if(mysqli_num_rows($result) > 0){

        $error[] = 'user already exist!';

    }
        else{
            $insert = "INSERT INTO form(email, discordname, discordmember, discordid, user_type, name, number, birth, gender, country, status, ronninwallet, image, game, scholarship, work, employee, salary, socmed, 
                tc, internet, payout, admins, playing, axie_terms, played_axie, guild_scholarship, lastscholarship, rank, scholarships_interested, stepn_agreement, question1, question2, question3, question4, question5, question6, question7, question8, question9, question10,
                question11, question12, question13, question14, question15, question16, question17, question18, question19, question20, played_stepn, guild_part, whydid_youleave, account_prefer, medical_conditions) 

            VALUES('$email','$discordname', '$discordmember', '$discordid','$user_type', '$name', '$number','$birth', '$gender', '$country', '$status', '$ronninwallet', '$image', '$game', '$scholarship', '$work', '$employee', '$salary', '$socmed',
                '$tc', '$internet', '$payout', '$admins', '$playing', '$axie_terms', '$played_axie', '$guild_scholarship', '$lastscholarship', '$rank', '$scholarships_interested', '$stepn_agreement', '$question1', '$question2', '$question3', '$question4', '$question5', '$question6', '$question7', '$question8', '$question9', '$question10',
                '$question11', '$question12', '$question13', '$question14', '$question15', '$question16', '$question17', '$question18', '$question19', '$question20', '$played_stepn', '$guild_part', '$whydid_youleave', '$account_prefer', '$medical_conditions')";
            mysqli_query($conn, $insert);
            header('location:thankyou.php');
        }

    
    
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRIBE</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

<div class="form-container" style="background-image: url('logoNew.jpg');">

    <form action="register_form.php" method="post">
        
        <h3><strong>TRIBE Scholar Application</strong></h3>
        <p>
        &nbsp;&nbsp;&nbsp;&nbsp; TRIBE Guild is a Play 2 Earn Guild that provides many opportunities for our scholars
         to earn and have fun together as a community! Currently we have incorporated 4 different P2E options.
         However, we are actively searching for more games to incorporate into our guild in the near future!
        </p>

        <h2>P2E Opportunities:</h2>
        <p>
            - Axie Infinity <br>
            - STEPN <br>
            - Axie Doll <br>
            - Sipher (Coming soon)
        </p>
        <p>Join our Discord Server to find out more:<a href="https://discord.gg/tribeguild" target="_blank">TRIBEGUILD</a> </p> 
        
        <h2>The application process will be conducted in these 5 stages: </h2>

        <h2>Stage 1:</h2><p>Choose which scholarship you are interested in (can apply to all)</p>
        <h2>Stage 2:</h2><p>Answer the short quiz, read the instruction how the quiz works.</p>
        <h2>Stage 3:</h2><p> Fill up your personal information and the scholar contract. </p>
        <h2>Stage 4:</h2><p>Go back to the ticket from 🎟・submit-a-ticket channel in TRIBE Discord Server and mention the Game Assistants that helped you with your application process.</p>
        <h2>Stage 5:</h2><p>Receive account details from the 🎟・</p>
        
        



        <?php
        if(isset($error)){
            foreach($error as $error){
                echo '<span class="error-msg">'.$error.'</span>';
            };
        };
        ?>
        <h2>Enter your email</h2>
        <input type="email" name="email" required placeholder="enter your email">

        <h2>Enter your discordname</h2>
        <input type="name" name="discordname" required placeholder="enter your discordname">
        
        <h2>Discord Member Since:</h2>
        <h2>Note:</h2><p>Click your profile to see this.</p>
        <img src="ex.png" alt="ex.png">
        <input type="text" name="discordmember" required placeholder="discord member since">
        
        <h2>Discord ID:</h2>
        <p>For example: 712622835738345524</p>
        <h2>Note:</h2><p>Put your discord to developer mode in setting to see the Discord ID.</p>
        <input type="text" name="discordid" required placeholder="enter your discord id">

        <h2>What scholarship are you interested in?</h2>
        <select name="user_type">
            <option value="axieinfinity">Axie Infinity</option>
            <option value="stepn">Stepn</option>
            <option value="axiedoll">Axie Doll</option>
            <option value="sipherwaitlist">Sipher (Waitlist)</option>
        </select>
        
        
        <!-- APPLICANT DETAILS -->
        <h1>Applicant Details</h1>
        <p>Please answer each question truthfully so we can know more about you!</p>
        <h2>Full Name</h2>
        <input type="name" name="name" required placeholder="enter your name">
        
        <h2>Contact Number</h2>
        <input type="text" name="number" required placeholder="enter your number">

        <h2>Date of Birth</h2>
        <input type="date" name="birth" required placeholder="enter your birth">

        <h2>Gender</h2>
        <input type="gender" name="gender" required placeholder="enter your gender">

        <h2>Country of Residence</h2>
        <input type="country" name="country" required placeholder="enter your country">
        
        <h2>Employment status</h2>
        <select name="status">
            <option value="fulltime">Full time : Employed</option>
            <option value="partime">Part time : Employed</option>
            <option value="unemployed">Unemployed</option>
            <option value="student">Student</option>
        </select>

        <h2>Personal ronin wallet for payout</h2>
        <p>If you don't have one yet, refer to this site to create one <a href="https://tribeguild.gitbook.io/tribe-information/axie-origin/axie-guides" target="_blank">Create one</a></p>
        <input type="ronninwallet" name="ronninwallet" required placeholder="enter your your wallet">

        <h2>Selfie with Identification Card</h2>
        <input type="file" name="image" name="filename">



        <!-- PERSONAL PROFILE -->
        <h1>Personal Profile</h1> <br>
        <h2>What other mobile/video games do you play?</h2>
        <input type="name" name="game" required placeholder="enter your game">
        
        <h2>Why do you want this scholarship?</h2>
        <input type="text" name="scholarship" required placeholder="enter your scholarship">
        
        <h2>We are looking for scholars that are able to bring value (e.g. Coder/SDK 
            Programmer/Social Media Manager/Website Design/Arena Coach/Digital  
            Artist/Live Streamer etc) to build our community! ence, we are looking 
            to hire part or full-time employees (paid salary) that can help to build the
            infrastructure for our Guild while providing our employees a scholarship
            too! Do list the skills 
            that you can contribute to this guild!
        </h2>
        <select name="work">
        <option value="fulltime">Administrative Work</option>
            <option value="partime">Live Streaming/ Coach</option>
            <option value="unemployed">Web-Design</option>
            <option value="student">Digital Artist/ Whitelist Artist</option>
            <option value="fulltime">Coder (e.g. create discord bots etc)</option>
            <option value="partime">SDK Programmer</option>
            <option value="unemployed">Nothing, I just want to be a scholar</option>
        </select>

        <h2>If you have any of the above listed skills, do explain further on your past experiences:</h2>
        <input type="text" name="skills" required placeholder="enter your answer">

        <h2>By contributing any of the above listed skills, are you interested to be a part or full-time employee?</h2>
        <select name="employee">
        <option value="fulltime">Part-time (4 hours per day)</option>
            <option value="partime">Full-time (8 hours per day)</option>
            <option value="unemployed">Only interested to be a scholar</option>
        </select>

        <h2>By contributing any of the above listed skills, what is your expected 𝙢𝙤𝙣𝙩𝙝𝙡𝙮 salary? (In USDC) Salary frequency will be twice monthly (1st & 15th) in USDC together with your scholar profits.</h2>
        <input type="country" name="salary" required placeholder="enter your answer">

        <h2>Please give us your Facebook/Instagram/LinkedIn name so we can make sure you are a real person</h2>
        <input type="country" name="socmed" required placeholder="enter your answer">



        <!-- THE TRIBE CONTACT -->
        <h1>The Tribe Contract</h1> <br>
        
        <h2>I agree to Tribe Guild's T&Cs and the game T&Cs 
            <a style="color: #febf3e;" href="https://tribeguild.gitbook.io/tribe-information/axie-origin">(Axie T&Cs</a> & 
            <a style="color: #febf3e;" href="https://tribeguild.gitbook.io/tribe-information/stepn/terms-and-conditions"> STEPN T&Cs)</a>.
            By breaking any T&Cs, your scholarship will be terminated with no payout/salary.
        </h2>
        <select name="tc">
        <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>

        <h2>Have access to internet connection & device (Hand Phone/Computer) and join the Discord server and be an active user.</h2>
        <select name="internet">
        <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>

        <h2>AXS/SLP/USDC Payout ratio : 50% Net profit sharing for the scholar (EXCEPTION if scholar does not reach minimum quota despite warnings)</h2>
        <select name="payout">
        <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>

        <h2>Admins will only pay out when: <br>
            (1) Scholar requests for it <br>
            (2) Audit Lead verified payouts are correct <br>
            (3) Paid out on mid/last day of month (SLP/AXS/USDC)
        </h2>
        <select name="admins">
        <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>

        <h2>I have left my previous scholarship and I am only playing for The TRIBE Guild now.</h2>
        <select name="playing">
        <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>


        <!-- AXIE INFINITY -->
        <h1>Axie Infinity</h1>
        <p>&nbsp;&nbsp;&nbsp;&nbsp; Axie Infinity is a game universe that has a player-owned economy where players can truly own, buy, sell, and trade resources they earn in the game through skilled-gameplay and contributions to the ecosystem.</p>
        <h2>TRIBE Guild has 3 adjacent mystic land plots, over 30 land items and owns over 1000 axies in total as of Oct 2022 with the goal of expanding to 500 scholars in 2023.</h2>
        <p>Check out: <a href="https://tribeguild.gitbook.io/tribe-information/" target="_blank">tribeguild.gitbook.io</a> to find out more about the Tribe Guild!</p>
        <p>Tribe Inventory: <a href="https://axieinfinity.com/terms/" target="_blank">axieinfinity.com</a> Click to View Inventory</p>
        
        <h2>Select if you agree</h2>
        <p>I agree to Tribe Guild's Terms and Conditions <a href="https://tribeguild.gitbook.io/tribe-information/axie-origin/terms-and-conditions"> tribeguild.gitbook.io</a> of the The TRIBE Guild Scholarship. and Axie Infinity Terms of Use <a href="https://axieinfinity.com/terms/">axieinfinity.com</a> Any breach of T&Cs will result in the scholarship being terminated with no payout/salary.</p>
        <select name="axie_terms">
            <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>

        <!-- Axie Infinity related questions. -->
        <h1>Axie Infinity related questions</h1><br>
        <h2>Have you played Axie Infinity before?</h2>
        <select name="played_axie">
            <option value="Yes">Yes</option>
            <option value="No">No</option>
        </select>

        <h2>Which guild/scholarship were you part of previously?</h2>
        <input type="text" name="guild_scholarship" required placeholder="enter your answer">

        <h2>When was the last day of your scholarship and why did you leave?</h2>
        <input type="text" name="lastscholarship" required placeholder="enter your answer">

        <h2>What was your rank in your previous scholarship and what team build did you play?</h2>
        <input type="text" name="rank" required placeholder="enter your answer">

        <h2>What other scholarships are you interested in?</h2>
        <select name="scholarships_interested">
            <option value="Axie Infinity">Axie Infinity</option>
            <option value="Stepn">Stepn</option>
            <option value="None? Then Proceed">None? Then Proceed</option>
        </select>

        <!-- Stepn -->
        <h1>Stepn</h1>
        <p>STEPN is built around an essential daily activity for most people-moving around. They are the first project to effectively bring to life a functioning move & earn concept.</p>
        <p>Users equip themselves with NFTs in the form of Sneakers which can be bought from the app marketplace. By walking, jogging, or running outdoors, users will earn game currency, which can either be used in-game, or cashed out for profit.</p>
        <p>TRIBE Guild is currently providing scholarship opportunities for scholars who areinterested in this project. We are equipped with an inventory of 300 STEPN Common Shoes (which includes Walker, Jogger & Runners) and our Tribe Leaders are always actively searching for sneakers for our scholars.  </p>
        <p>check out: <a href="https://tribeguild.gitbook.io/tribe-information/" target="_blank">tribeguild.gitbook.io</a> to find out more about the Tribe Guild!</p>
        <h2>Select if you agree</h2>
        <p>I agree to the Terms and Conditions <a href="https://tribeguild.gitbook.io/tribe-information/stepn/terms-and-conditions" target="_blank">tribeguild.gitbook.io</a> of the The TRIBE Guild Scholarship</p>
        <p>I agree to the Stepn Terms of Use <a href="https://www.stepnguides.com/terms-and-conditions" target="_blank">www.stepnguides.com</a> any action that results in a ban will lead to a forfeit of scholarship and any unpaid profits</p>
        <select name="stepn_agreement">
            <option value="I agree">I agree</option>
            <option value="I disagree">I disagree</option>
        </select>


        <!-- Stepn Beginner's Quiz -->
        <h1>Stepn Beginner's Quiz</h1>
        <p>Some basic questions to assess your knowledge about the game. Please select the best answer to proceed to the next question. You will be brought back to the question again if you have chosen the wrong answer.</p>
        
        <h1>Question 1</h1><br>
        <h2>How much GMT & GST will it cost to level up from Lvl 9 to Lvl 10?</h2>
        <select name="question1">
            <option value="20 GST and GMT">20 GST and GMT</option>
            <option value="30 GST and GMT">30 GST and GMT</option>
            <option value="40 GST and GMT">40 GST and GMT</option>
            <option value="50 GST and GMT">50 GST and GMT</option>
        </select>

        <h1>Question 2</h1><br>
        <h2>How to allocate attribute point for Comfort build shoe?</h2>
        <select name="question2">
            <option value="Having at least 10 Resilience and all in to Comfort">Having at least 10 Resilience and all in to Comfort</option>
            <option value="Having at least 15 Resilience and all in to Comfort">Having at least 15 Resilience and all in to Comfort</option>
            <option value="Having at least 20 Resilience and all in to Comfort">Having at least 20Resilience and all in to Comfort</option>
            <option value="Having at least 25 Resilience and all in to Comfort">Having at least 25 Resilience and all in to Comfort</option> 
        </select>

        <h1>Question 3</h1><br>
        <h2>Why do we need to restore HP?</h2>
        <select name="question3">
            <option value="If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore">If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore</option>
            <option value="If HP < 30%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore">If HP < 30%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore</option>
            <option value="If HP < 40%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore">If HP < 40%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore</option>
            <option value="If HP < 50%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore">If HP < 50%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore</option> 
        </select>

        <h1>Question 4</h1><br>
        <h2>Minimum attribute required for comfort & resilience?</h2>
        <select name="question4">
            <option value="5 Comf & Res">5 Comf & Res</option>
            <option value="10 Comf & Res">10 Comf & Res</option>
            <option value="15 Comf & Res">15 Comf & Res</option>
            <option value="20 Comf & Res">20 Comf & Res</option>
        </select>

        <h1>Question 5</h1><br>
        <h2>Minimum attribute required for comfort & resilience?</h2>
        <select name="question5">
            <option value="Level 20">Level 20</option>
            <option value="Level 23">Level 23</option>
            <option value="Level 25">Level 25</option>
            <option value="Level 30">Level 30</option>
        </select>

        <h1>Question 6</h1><br>
        <h2>How much GST and GMT does it cost to level up from 19-20?</h2>
        <select name="question6">
            <option value="10 GMT & GST">10 GMT & GST</option>
            <option value="60 GMT & GST">60 GMT & GST</option>
            <option value="100 GMT & GST">100 GMT & GST</option>
            <option value="30 GMT & GST">30 GMT & GST</option>
        </select>

        <h1>Question 7</h1><br>
        <h2>Mystery Box Level Chart</h2>
        <img style="width: 400px" src="question7.png" alt="question7">
        <h2>Assuming you have at least 60 attribute luck, and do the 5 energy run, what level of mystery box will you accumulate?</h2>
        <select name="question7">
            <option value="Level 3 MB">Level 3 MB</option>
            <option value="Level 4 MB">Level 4 MB</option>
            <option value="Level 5 MB">Level 5 MB</option>
            <option value="Level 6 MB">Level 6 MB</option>
        </select>

        <h1>Question 8</h1><br>
        <h2>Mystery Box Item Drops</h2>
        <img style="width: 400px" src="question8.png" alt="question8">
        <h2>To have a chance to win a Lv 2 Gem from a Mystery Box, what is the minimum level required for the Mystery Box?</h2>
        <select name="question8">
            <option value="Level 2 MB">Level 2 MB</option>
            <option value="Level 3 MB">Level 3 MB</option>
            <option value="Level 4 MB">Level 4 MB</option>
            <option value="Level 5 MB">Level 5 MB</option>
        </select>

        <h1>Question 9</h1> <br>
        <h2>As Lv 1 & 2 MB are a guaranteed loss in the long-run, only open Lv 3 & above MBs. (Unless it is to clear a slot to fit a higher level MB)</h2>
        <select name="question9">
            <option value="I Understand.">I Understand.</option>
        </select>

        <h1>Question 10</h1> <br>
        <h2>125% energy ratio : if you have 3 shoes that have 4 energy, how to do 5 energy run?</h2>
        <select name="question10">
            <option value="Start the run earliest 20 minutes before Energy Regeneration.">Start the run earliest 20 minutes before Energy Regeneration</option>
            <option value="Start the run 30 minutes before Energy Regeneration">Start the run 30 minutes before Energy Regeneration</option>
            <option value="Start the run 30 minutes after Energy Regeneration">Start the run 30 minutes after Energy Regeneration</option>
            <option value="Start the run 25 minutes before Energy Regeneration">Start the run 25 minutes before Energy Regeneration</option>
        </select>

        <h1>Question 11</h1> <br>
        <h2>What sneaker level unlocks GMT Earnings?</h2>
        <select name="question11">
            <option value="Level 15">Level 15</option>
            <option value="Level 20">Level 20</option>
            <option value="Level 25">Level 25</option>
            <option value="Level 30">Level 30</option>
        </select>

        
        <h1>Question 12</h1> <br>
        <h2>For Common Shoes, how much HP do Lv 1 & 2 & 3 Comfort Gems restore?</h2>
        <select name="question12">
            <option value="5%, 50% & 100% respectively">5%, 50% & 100% respectively</option>
            <option value="3%, 39% & 100% respectively">3%, 39% & 100% respectively</option>
            <option value="2%, 20% & 50% respectively">2%, 20% & 50% respectively</option>
            <option value="8%, 69% & 88% respectively">8%, 69% & 88% respectively</option>
        </select>

        <h1>Question 13</h1> <br>
        <h2>For Uncommon Shoes, how much HP do Lv 1 & 2 & 3 Comfort Gems restore?</h2>
        <select name="question13">
            <option value="5%, 50% & 100% respectively">5%, 50% & 100% respectively</option>
            <option value="3%, 39% & 100% respectively">3%, 39% & 100% respectively</option>
            <option value="2%, 20% & 50% respectively">2%, 20% & 50% respectively</option>
            <option value="8%, 69% & 88% respectively">8%, 69% & 88% respectively</option>
        </select>
        
        <h1>Question 14</h1> <br>
        <h2>How much GST is used during HP restore for Lv 1 & 2 & 3 Comfort Gems?</h2>
        <select name="question14">
            <option value="1, 5 & 10 GST respectively">1, 5 & 10 GST respectively</option>
            <option value="5. 10 & 20 GST respectively">5. 10 & 20 GST respectively</option>
            <option value="10, 30 & 100 GST respectively">10, 30 & 100 GST respectively</option>
            <option value="20, 50 & 200 GST respectively">20, 50 & 200 GST respectively</option>
        </select>

        <h1>Question 15</h1> <br>
        <h2>If a Common shoe is at 96% HP, how many Lv 1 Comf gem you need to buy to restore HP to 100%?</h2>
        <select name="question15">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
        </select>

        <h1>Question 16</h1>
        <p>Please use <a href="https://stepn.guide/" target="_blank">STEPN GUIDE CALCULATOR</a> to solve the problem:</p>
        <h2>Common Shoe</h2>
        <p>Level 1 shoe have limited stat points. Priority is to get Comf & Res to minimum 10 stats first; hence all attribute points will be added to Comf first.</p>
        <img src="question16.png" alt="question16">
        <h2>For the shoe above: How much does the durability repair cost?</h2>
        <select name="question16">
            <option value="2.55 GST">2.55 GST</option>
            <option value="1.32 GST">1.32 GST</option>
            <option value="1.86 GST">1.86 GST</option>
            <option value="6 GST">6 GST</option>
        </select>

        <h1>Question 17</h1> <br>
        <h2>For the shoe above: <br>How much does the daily 2 energy HP restore cost in GST? Assuming Lv 1 Comf gem costs 70 GST. The SOL price can be found <a href="https://stepnfp.com/" target="_blank">stepnfp.com</a> then converted to GST using <a href="https://coinchefs.com/sol/gst/"></a> coinchefs.com</h2>
        <select name="question17">
            <option value="8 GST">8 GST</option>
            <option value="60 GST">60 GST</option>
            <option value="70 GST">70 GST</option>
            <option value="80 GST">80 GST</option>
        </select>

        <h1>Question 18</h1> <br>
        <h2>For the shoe above: <br>What is the GST earned for a 2 energy run? (Before durability repair/HP restore)</h2>
        <select name="question18">
            <option value="2.42 GSTT">2.42 GST</option>
            <option value="5.34 GST">5.34 GST</option>
            <option value="6.84 GST">6.84 GST</option>
            <option value="3.48 GST">3.48 GST</option>
        </select>

        <h1>Question 19</h1> <br>
        <h2>For the shoe above: <br>What is the Nett GST daily income? (After durability repair and HP restore)</h2>
        <select name="question19">
            <option value="-1.86 GST">-1.86 GST</option>
            <option value="3.48 GST">3.48 GST</option>
            <option value="-4.52 GST">-4.52 GST</option>
            <option value="5.34 GST">5.34 GST</option>
        </select>

        <h1>Question 20</h1> <br>
        <h2>For the shoe above: <br>After doing the calculations, will you still continue to run with this shoe and recommend a solution? (Please explain why)</h2>
        <input type="text" name="question20" required placeholder="enter your answer">

        <!-- STEPN Related Questions -->
        <h1>STEPN Related Questions</h1><br>
        <h2>Have you played STEPN before?</h2>
        <select name="played_stepn">
            <option value="Yes">Yes</option>
            <option value="No">No</option>
        </select>

        <h2>Which guild/scholarship were you part of previously?</h2>
        <input type="text" name="guild_part" required placeholder="enter your answer">

        <h2>When was the last day of your scholarship and why did you leave?</h2>
        <input type="text" name="whydid_youleave" required placeholder="enter your answer">

        <h2>What would you prefer your account to be?</h2>
        <select name="account_prefer">
            <option value="Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST">Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST</option>
            <option value="Jogger — 4-10km/hr 1:Untitleddesign2:= 5 GST">Jogger — 4-10km/hr 1:Untitleddesign2:= 5 GST</option>
            <option value="Runner — 8-20km/hr 1:Untitleddesign2:= 6 GST">Runner — 8-20km/hr 1:Untitleddesign2:= 6 GST</option>
        </select>

        <h2>Do you have any medical conditions? (If yes, explain what type of medical conditions you have. If none, just type "None")</h2>
        <input type="text" name="medical_conditions" required placeholder="enter your answer">

        <!-- SUBMIT BUTTON -->
        <input type="submit" name="submit" value="Submit" class="form-btn">



    </form>

</div>
    
</body>
</html>