<?php

$conn = mysqli_connect('localhost','tribeformdatabase','tribeformdatabase','tribe_form');
// mysqli_select_db($con, '');
?>