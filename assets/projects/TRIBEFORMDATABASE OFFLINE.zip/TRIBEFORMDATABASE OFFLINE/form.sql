-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2023 at 04:04 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tribe_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `discordname` varchar(255) NOT NULL,
  `discordmember` varchar(255) NOT NULL,
  `discordid` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `birth` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `ronninwallet` varchar(255) NOT NULL,
  `image` blob NOT NULL,
  `game` varchar(255) NOT NULL,
  `scholarship` varchar(255) NOT NULL,
  `work` varchar(255) NOT NULL,
  `skills` varchar(255) NOT NULL,
  `employee` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `socmed` varchar(255) NOT NULL,
  `tc` varchar(255) NOT NULL,
  `internet` varchar(255) NOT NULL,
  `payout` varchar(255) NOT NULL,
  `admins` varchar(255) NOT NULL,
  `playing` varchar(255) NOT NULL,
  `axie_terms` varchar(255) NOT NULL,
  `played_axie` varchar(255) NOT NULL,
  `guild_scholarship` varchar(255) NOT NULL,
  `lastscholarship` varchar(255) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `scholarships_interested` varchar(255) NOT NULL,
  `stepn_agreement` varchar(255) NOT NULL,
  `question1` varchar(255) NOT NULL,
  `question2` varchar(255) NOT NULL,
  `question3` varchar(255) NOT NULL,
  `question4` varchar(255) NOT NULL,
  `question5` varchar(255) NOT NULL,
  `question6` varchar(255) NOT NULL,
  `question7` varchar(255) NOT NULL,
  `question8` varchar(255) NOT NULL,
  `question9` varchar(255) NOT NULL,
  `question10` varchar(255) NOT NULL,
  `question11` varchar(255) NOT NULL,
  `question12` varchar(255) NOT NULL,
  `question13` varchar(255) NOT NULL,
  `question14` varchar(255) NOT NULL,
  `question15` varchar(255) NOT NULL,
  `question16` varchar(255) NOT NULL,
  `question17` varchar(255) NOT NULL,
  `question18` varchar(255) NOT NULL,
  `question19` varchar(255) NOT NULL,
  `question20` varchar(255) NOT NULL,
  `played_stepn` varchar(255) NOT NULL,
  `guild_part` varchar(255) NOT NULL,
  `whydid_youleave` varchar(255) NOT NULL,
  `account_prefer` varchar(255) NOT NULL,
  `medical_conditions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `email`, `discordname`, `discordmember`, `discordid`, `user_type`, `name`, `number`, `birth`, `gender`, `country`, `status`, `ronninwallet`, `image`, `game`, `scholarship`, `work`, `skills`, `employee`, `salary`, `socmed`, `tc`, `internet`, `payout`, `admins`, `playing`, `axie_terms`, `played_axie`, `guild_scholarship`, `lastscholarship`, `rank`, `scholarships_interested`, `stepn_agreement`, `question1`, `question2`, `question3`, `question4`, `question5`, `question6`, `question7`, `question8`, `question9`, `question10`, `question11`, `question12`, `question13`, `question14`, `question15`, `question16`, `question17`, `question18`, `question19`, `question20`, `played_stepn`, `guild_part`, `whydid_youleave`, `account_prefer`, `medical_conditions`) VALUES
(1, 'cymerdenampo@gmail.com', 'Cymer', 'August 03, 2021', 'Cymer#3823', 'axieinfinity', 'Cymer Jacob Denampo', '0945-164-2872', '2001-04-11', 'Male', 'Philippines', 'fulltime', 'ronin:aac4001e7929e1ef0feff58616f10baf657afb05', '', 'Dota 2', 'To have fun and at the same time to help my personal matters', 'unemployed', '', 'partime', '$800', 'Cymer Denampo', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'Yes', 'none', 'none', 'none', 'Axie Infinity', 'I agree', '20 GST and GMT', 'Having at least 10 Resilience and all in to Comfort', 'If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore', '5 Comf & Res', 'Level 20', '10 GMT & GST', 'Level 3 MB', 'Level 2 MB', 'I Understand.', 'Start the run earliest 20 minutes before Energy Regeneration.', 'Level 15', '5%, 50% & 100% respectively', '5%, 50% & 100% respectively', '1, 5 & 10 GST respectively', '1', '2.55 GST', '8 GST', '2.42 GSTT', '-1.86 GST', 'none', 'Yes', 'none', 'none', 'Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST', 'none'),
(2, 'lucifermorningstar@gmail.com', 'Cymer', 'August 03, 2021', 'Cymer#3823', 'axieinfinity', 'Cymer Jacob Denampo', '0945-164-2872', '2001-04-11', 'Male', 'Philippines', 'fulltime', 'ronin:aac4001e7929e1ef0feff58616f10baf657afb05', '', 'Dota 2', 'To have fun and at the same time to help my personal matters', 'unemployed', '', 'partime', '$800', 'Cymer Denampo', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'Yes', 'none', 'none', 'none', 'Axie Infinity', 'I agree', '20 GST and GMT', 'Having at least 10 Resilience and all in to Comfort', 'If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore', '5 Comf & Res', 'Level 20', '10 GMT & GST', 'Level 3 MB', 'Level 2 MB', 'I Understand.', 'Start the run earliest 20 minutes before Energy Regeneration.', 'Level 15', '5%, 50% & 100% respectively', '5%, 50% & 100% respectively', '1, 5 & 10 GST respectively', '1', '2.55 GST', '8 GST', '2.42 GSTT', '-1.86 GST', 'none', 'Yes', 'none', 'none', 'Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST', 'none'),
(3, 'sample@gmail.com', 'Cymer', 'August 03, 2021', 'Cymer#3823', 'axieinfinity', 'Cymer Jacob Denampo', '0945-164-2872', '2001-04-11', 'Male', 'Philippines', 'fulltime', 'ronin:aac4001e7929e1ef0feff58616f10baf657afb05', '', 'Dota 2', 'To have fun and at the same time to help my personal matters', 'student', '', 'partime', '$800', 'Cymer Denampo', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'Yes', 'none', 'none', 'none', 'Axie Infinity', 'I agree', '20 GST and GMT', 'Having at least 10 Resilience and all in to Comfort', 'If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore', '5 Comf & Res', 'Level 20', '10 GMT & GST', 'Level 3 MB', 'Level 2 MB', 'I Understand.', 'Start the run earliest 20 minutes before Energy Regeneration.', 'Level 15', '5%, 50% & 100% respectively', '5%, 50% & 100% respectively', '1, 5 & 10 GST respectively', '1', '2.55 GST', '8 GST', '2.42 GSTT', '-1.86 GST', 'none', 'Yes', 'none', 'none', 'Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST', 'none'),
(4, 'cymerjacobdenampo@gmail.com', 'Cymer', 'August 03, 2021', 'Cymer#3823', 'axieinfinity', 'Cymer Jacob Denampo', '0945-164-2872', '2001-04-11', 'Male', 'Philippines', 'fulltime', 'ronin:aac4001e7929e1ef0feff58616f10baf657afb05', '', 'Dota 2', 'To have fun and at the same time to help my personal matters', 'fulltime', '', 'fulltime', '$800', 'Cymer Denampo', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'I agree', 'Yes', 'none', 'none', 'none', 'Axie Infinity', 'I agree', '20 GST and GMT', 'Having at least 10 Resilience and all in to Comfort', 'If HP < 20%, Sneaker cannot be counted to provide energy and once 0%, the Sneaker cannot be used anymore', '5 Comf & Res', 'Level 20', '10 GMT & GST', 'Level 3 MB', 'Level 2 MB', 'I Understand.', 'Start the run earliest 20 minutes before Energy Regeneration.', 'Level 15', '5%, 50% & 100% respectively', '5%, 50% & 100% respectively', '1, 5 & 10 GST respectively', '1', '2.55 GST', '8 GST', '2.42 GSTT', '-1.86 GST', 'none', 'Yes', 'none', 'none', 'Walker — 1-6km/hr 1:Untitleddesign2:= 4 GST', 'none');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
