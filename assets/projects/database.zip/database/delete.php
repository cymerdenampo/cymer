<?php
if ( isset ($_GET["id"]) ) {
    $id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "axie_revenue_db";

    // Create a connection
    $connection = new mysqli($servername, $username, $password, $database);

    $sql = "DELETE FROM axie WHERE id=$id";
    $connection->query($sql);
}

    header("location: /database/index.php");
    exit;
?>