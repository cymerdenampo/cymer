<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AXIE SHEET</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body style="background-color: ">
    <div class="container my-5">
        <h2>Lists</h2>
        <a class="btn btn-primary" href="/database/create.php" role="button">Add New</a>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Requestor</th>
                    <th>R&C Type</th>
                    <th>R&C Rarity</th>
                    <th>R&C requested for sale</th>
                    <th>Quantity</th>
                    <th>Starting Price</th>
                    <th>Ending Price</th>
                    <th>Auction Days</th>
                    <th>Sold Price (ETH)</th>
                    <th>Date Sold</th>
                    <th>Mint Fee (USD)</th>
                    <th>Sold Price (USD)</th>
                    <th>Net Profit (USD)</th>
                    <th>Scholar's Cut (USD)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "axie_revenue_db";

                $connection = new mysqli($servername, $username, $password, $database);

                if($connection->connect_error){
                    die("Connection failed:". $connection->connect_error);
                }

                $sql = "SELECT * FROM axie";
                $result = $connection->query($sql);

                if (!$result){
                    die("Invalid query:". $connection->connect_error);
                }

                while($row = $result->fetch_assoc()){
                    echo"
                    <tr>
                    <td>$row[id]</td>
                    <td>$row[Requestor]</td>
                    <td>$row[RC_Type]</td>
                    <td>$row[RC_Rarity]</td>
                    <td>$row[RC_requested_for_sale]</td>
                    <td>$row[Quantity]</td>
                    <td>$row[Starting_Price]</td>
                    <td>$row[Ending_Price]</td>
                    <td>$row[Auction_Days]</td>
                    <td>$row[Sold_Price_ETH]</td>
                    <td>$row[Date_Sold]</td>
                    <td>$row[Mint_Fee_USD]</td>
                    <td>$row[Sold_Price_USD]</td>
                    <td>$row[Net_Profit_USD]</td>
                    <td>$row[Scholars_Cut_USD]</td>
                    <td>
                        <a class='btn btn-primary btn-sm' href='/database/edit.php?id=$row[id]'>Edit</a>
                        <a class='btn btn-primary btn-sm' href='/database/delete.php?id=$row[id]'>Delete</a>
                    </td>
                </tr>
                    ";
                }
                
                ?>
                
            </tbody>
        </table>

    </div>
</body>
</html>