-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2023 at 09:30 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `axie_revenue_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `axie`
--

CREATE TABLE `axie` (
  `id` int(11) NOT NULL,
  `Requestor` varchar(255) NOT NULL,
  `RC_Type` varchar(255) NOT NULL,
  `RC_Rarity` varchar(255) NOT NULL,
  `RC_requested_for_sale` varchar(255) NOT NULL,
  `Quantity` varchar(255) NOT NULL,
  `Starting_Price` varchar(255) NOT NULL,
  `Ending_Price` varchar(255) NOT NULL,
  `Auction_Days` varchar(255) NOT NULL,
  `Sold_Price_ETH` varchar(255) NOT NULL,
  `Date_Sold` varchar(255) NOT NULL,
  `Mint_Fee_USD` varchar(255) NOT NULL,
  `Sold_Price_USD` varchar(255) NOT NULL,
  `Net_Profit_USD` varchar(255) NOT NULL,
  `Scholars_Cut_USD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `axie`
--

INSERT INTO `axie` (`id`, `Requestor`, `RC_Type`, `RC_Rarity`, `RC_requested_for_sale`, `Quantity`, `Starting_Price`, `Ending_Price`, `Auction_Days`, `Sold_Price_ETH`, `Date_Sold`, `Mint_Fee_USD`, `Sold_Price_USD`, `Net_Profit_USD`, `Scholars_Cut_USD`) VALUES
(1, 'Chtulhu', 'Charm', 'Epic', 'Plants Charm of Vitality II', '1', '-', '-', '-', '0.0036993', '20 Dec', '$2.50', '-', '-', '-'),
(2, 'Chtulhu', 'Charm', 'Epic', 'Trickters Card', '1', '-', '-', '-', '0.002993', '20 Dec', '$2.50', '$3.64', '$0.99', '$0.495'),
(3, 'Azor', 'Rune', 'Epic', 'Sacred Feather', '1', '-', '-', '-', '0.0111', '26 Jan', '$5.00', '$17.77', '$12.02', '$6.008');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `axie`
--
ALTER TABLE `axie`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `axie`
--
ALTER TABLE `axie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
