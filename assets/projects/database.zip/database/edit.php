<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "axie_revenue_db";

// Create a connection
$connection = new mysqli($servername, $username, $password, $database);

$Requestor = "";
$RC_Type = "";
$RC_Rarity = "";
$RC_requested_for_sale = "";
$Quantity = "";
$Starting_Price = "";
$Ending_Price = "";
$Auction_Days = "";
$Sold_Price_ETH = "";
$Date_Sold = "";
$Mint_Fee_USD = "";
$Sold_Price_USD = "";
$Net_Profit_USD = "";
$Scholars_Cut_USD = "";

$errorMessage = "";
$successMessage = "";

if ( $_SERVER['REQUEST_METHOD'] == 'GET' ) {
    //GET method: show the data of client

    if ( !isset($_GET["id"]) ) {
        header("location: /database/index.php");
        exit;
    }

    $id = $_GET["id"];

    //read the row of the selected client from database table
    $sql = "SELECT * FROM axie WHERE id=$id";
    $result = $connection->query($sql);
    $row = $result->fetch_assoc();

    if (!$row) {
        header("location: /database/index.php");
        exit;
    }
    
    $Requestor = $row["Requestor"];
    $RC_Type = $row["RC_Type"];
    $RC_Rarity = $row["RC_Rarity"];
    $RC_requested_for_sale = $row["RC_requested_for_sale"];
    $Quantity = $row["Quantity"];
    $Starting_Price = $row["Starting_Price"];
    $Ending_Price = $row["Ending_Price"];
    $Auction_Days = $row["Auction_Days"];
    $Sold_Price_ETH = $row["Sold_Price_ETH"];
    $Date_Sold = $row["Date_Sold"];
    $Mint_Fee_USD = $row["Mint_Fee_USD"];
    $Sold_Price_USD = $row["Sold_Price_USD"];
    $Net_Profit_USD = $row["Net_Profit_USD"];
    $Scholars_Cut_USD = $row["Scholars_Cut_USD"];

}
else{
    //POST method: Update the data of the client

    $id = $_POST["id"];
    $Requestor = $_POST["Requestor"];
    $RC_Type = $_POST["RC_Type"];
    $RC_Rarity = $_POST["RC_Rarity"];
    $RC_requested_for_sale = $_POST["RC_requested_for_sale"];
    $Quantity = $_POST["Quantity"];
    $Starting_Price = $_POST["Starting_Price"];
    $Ending_Price = $_POST["Ending_Price"];
    $Auction_Days = $_POST["Auction_Days"];
    $Sold_Price_ETH = $_POST["Sold_Price_ETH"];
    $Date_Sold = $_POST["Date_Sold"];
    $Mint_Fee_USD = $_POST["Mint_Fee_USD"];
    $Sold_Price_USD = $_POST["Sold_Price_USD"];
    $Net_Profit_USD = $_POST["Net_Profit_USD"];
    $Scholars_Cut_USD = $_POST["Scholars_Cut_USD"];

    do {
        if ( empty($Requestor) || empty($RC_Type) || empty($RC_Rarity) || empty($RC_requested_for_sale) || empty($Quantity) || empty($Starting_Price) || empty($Ending_Price) ||
                empty($Auction_Days) || empty($Sold_Price_ETH) || empty($Date_Sold) || empty($Mint_Fee_USD) || empty($Sold_Price_USD) || empty($Net_Profit_USD) || empty($Scholars_Cut_USD) ) {
            $errorMessage = "All the fields are required";
            break;
        }
        $sql = "UPDATE axie " .
            "SET Requestor = '$Requestor', RC_Type = '$RC_Type', RC_Rarity = '$RC_Rarity', RC_requested_for_sale = '$RC_requested_for_sale', Quantity = '$Quantity', Starting_Price = '$Starting_Price', Ending_Price = '$Ending_Price', 
                Auction_Days = '$Auction_Days', Sold_Price_ETH = '$Sold_Price_ETH', Date_Sold = '$Date_Sold', Mint_Fee_USD = '$Mint_Fee_USD', Sold_Price_USD = '$Sold_Price_USD', Net_Profit_USD = '$Net_Profit_USD', Scholars_Cut_USD = '$Scholars_Cut_USD' " .
            "WHERE id = $id";

        $result = $connection->query($sql);

        if (!$result) {
            $errorMessage = "Invalid query: " . $connection->error;
            break;
        }

        $successMessage = "Client added correctly";

        header("location: /database/index.php");
        exit;

    } while (false);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AXIE SHEET</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container my-5">
        <h2>Edit</h2>

        <?php
        if ( !empty($errorMessage) ) {
            echo"
            <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                <strong>$errorMessage</strong>
                <button type='buton' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";
        }        
        ?>

        <form method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Requestor</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Requestor" value="<?php echo $Requestor; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">R&C Type</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="RC_Type" value="<?php echo $RC_Type; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">R&C Rarity</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="RC_Rarity" value="<?php echo $RC_Rarity; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">R&C requested for sale</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="RC_requested_for_sale" value="<?php echo $RC_requested_for_sale; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Quantity</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Quantity" value="<?php echo $Quantity; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Starting Price</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Starting_Price" value="<?php echo $Starting_Price; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Ending Price</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Ending_Price" value="<?php echo $Ending_Price; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Auction Days</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Auction_Days" value="<?php echo $Auction_Days; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Sold Price (ETH)</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Sold_Price_ETH" value="<?php echo $Sold_Price_ETH; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Date Sold</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Date_Sold" value="<?php echo $Date_Sold; ?>">
                </div>
            </div> 
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Mint Fee (USD)</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Mint_Fee_USD" value="<?php echo $Mint_Fee_USD; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Sold Price (USD)</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Sold_Price_USD" value="<?php echo $Sold_Price_USD; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Net Profit (USD)</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Net_Profit_USD" value="<?php echo $Net_Profit_USD; ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Scholar's Cut (USD)</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Scholars_Cut_USD" value="<?php echo $Scholars_Cut_USD; ?>">
                </div>
            </div>


            <?php
            if ( !empty($successMessage) ) {
                echo "
                <div class='row mb-3'>
                    <div class='offset-sm-3 col-sm-6'>
                        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                            <strong>$successMessage</strong>
                            <button type='buton' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                        </div>
                    </div>
                </div>
                ";
            }
            ?>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="/database/index.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html> 