<?php

@include 'config.php';

if(isset($_POST['submit'])){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $number = mysqli_real_escape_string($conn, $_POST['number']);
    $birth = ($_POST['birth']);
    $gender = ($_POST['gender']);
    $country = ($_POST['country']);
    $status = ($_POST['status']);
    $ronninwallet = ($_POST['ronninwallet']);
    // $cpass = md5($_POST['cpassword']);
    $image = $_POST['image'];

    $select = " SELECT * FROM form WHERE email = '$name' ";

    $result = mysqli_query($conn, $select);

    if(mysqli_num_rows($result) > 0){

        $error[] = 'user already exist!';

    }else{
        if($pass != $cpass){
            $error[] = 'password not matched!';
        }else{
            $insert = "INSERT INTO form(name, number, birth, gender, country, status, ronninwallet, image) 
            VALUES('$name', '$number','$birth', '$gender', '$country', '$status', '$ronninwallet', '$image')";
            mysqli_query($conn, $insert);
            header('location:3ndpage.php');
        }

    }
    
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRIBE</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>

<div class="form-container">

    <form action="" method="post">
        
        <h3><strong>TRIBE Scholar Application</strong></h3>
        <p>
        <!-- &nbsp;&nbsp;&nbsp;&nbsp; TRIBE Guild is a Play 2 Earn Guild that provides many opportunities for our scholars
         to earn and have fun together as a community! Currently we have incorporated 4 different P2E options.
         However, we are actively searching for more games to incorporate into our guild in the near future!
        </p>

        <h2>P2E Opportunities:</h2>
        <p>
            - Axie Infinity <br>
            - STEPN <br>
            - Axie Doll <br>
            - Sipher (Coming soon)
        </p>
        <p>Join our Discord Server to find out more:<a href="https://discord.gg/tribeguild" target="_blank">TRIBEGUILD</a> </p> 
        
        <h2>The application process will be conducted in these 5 stages: </h2>

        <h2>Stage 1:</h2><p>Choose which scholarship you are interested in (can apply to all)</p>
        <h2>Stage 2:</h2><p>Answer the short quiz, read the instruction how the quiz works.</p>
        <h2>Stage 3:</h2><p> Fill up your personal information and the scholar contract. </p>
        <h2>Stage 4:</h2><p>Go back to the ticket from 🎟・submit-a-ticket channel in TRIBE Discord Server and mention the Game Assistants that helped you with your application process.</p>
        <h2>Stage 5:</h2><p>Receive account details from the 🎟・</p> -->
        
        <?php
        if(isset($error)){
            foreach($error as $error){
                echo '<span class="error-msg">'.$error.'</span>';
            };
        };
        ?>
        <!-- <h2>Enter your email</h2>
        <input type="email" name="email" required placeholder="enter your email">
        
        <h2>Discord Member Since:</h2>
        <h2>Note:</h2><p>Click your profile to see this.</p>
        <img src="ex.png" alt="ex.png">
        <input type="text" name="discordmember" required placeholder="discord member since">
        
        <h2>Discord ID:</h2>
        <p>For example: 712622835738345524</p>
        <h2>Note:</h2><p>Put your discord to developer mode in setting to see the Discord ID.</p>
        <input type="text" name="discordid" required placeholder="enter your discord id">

        <h2>What scholarship are you interested in?</h2> -->
        <!-- <input type="password" name="cpassword" required placeholder="confirm your password"> -->
        <!-- <select name="user_type">
            <option value="axieinfinity">Axie Infinity</option>
            <option value="stepn">Stepn</option>
            <option value="axiedoll">Axie Doll</option>
            <option value="sipherwaitlist">Sipher (Waitlist)</option>
        </select> -->
        
        
        <!-- <select name="user_type">
            <option value="user">user</option>
            <option value="admin">admin</option>
        </select> -->

        <!-- <input type="submit" name="submit" value="Next" class="form-btn"> -->
        <!-- <p>already have an account? <a href="login_form.php">login now</a></p> -->
        
        <!-- APPLICANT DETAILS -->
        <h1>Applicant Details</h1>
        <p>Please answer each question truthfully so we can know more about you!</p>
        <h2>Full Name</h2>
        <input type="name" name="name" required placeholder="enter your name">
        
        <h2>Contact Number</h2>
        <input type="text" name="number" required placeholder="enter your number">

        <h2>Date of Birth</h2>
        <input type="date" name="birth" required placeholder="enter your birth">

        <h2>Gender</h2>
        <input type="gender" name="gender" required placeholder="enter your gender">

        <h2>Country of Residence</h2>
        <input type="country" name="country" required placeholder="enter your country">

        <select name="status">
            <option value="fulltime">Full time : Employed</option>
            <option value="partime">Part time : Employed</option>
            <option value="unemployed">Unemployed</option>
            <option value="student">Student</option>
        </select>

        <h2>Personal ronin wallet for payout</h2>
        <p>If you don't have one yet, refer to this site to create one <a href="https://tribeguild.gitbook.io/tribe-information/axie-origin/axie-guides" target="_blank">Create one</a></p>
        <input type="ronninwallet" name="ronninwallet" required placeholder="enter your your wallet">

        <h2>Selfie with Identification Card</h2>
        <!-- <form action="/action_page.php"> -->
        <input type="file" name="image" name="filename">

        <input type="submit" name="submit" value="Next" class="form-btn">

    </form>

</div>
    
</body>
</html>